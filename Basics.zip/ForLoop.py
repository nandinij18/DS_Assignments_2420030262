fruits=["apple,""banana","cherry"]
for x in fruits:
    print(x)
    
    
#range() function
for x in range(6):
    print(x)
    

#WRITE A PROGRAM TO PRINT THE EVEN NUMBERS FROM 1 TO 100
for x in range(1,101):
    if x%2==0:
        print(x)
        
#write a program to check whether the given number is palindrome or not

num = input("Enter a number: ")
if num == num[::-1]:     # check if the number is equal to its reverse
    print(num, "is a palindrome")
else:
    print(num, "is not a palindrome")
    
""""num=int(input("Enter the number: "))
temp=num
reverse=0
while(num>0):
    digit=num%10
    reverse=reverse*10+digit
    num=num//10
if(temp==reverse):
    print("The number is palindrome")
else:
    print("The number is not palindrome") """"
    

#WRITE A PROGRAM TO PRINT IT IS PRIME OR NOT
num=int(input("Enter the number: "))
is_prime=True
for i in range(2,num):      #check if the number is divisible by any number from 2 to num
    if num%i==0:
        is_prime=False
        break
if is_prime:
    print("The number is prime")
else:
    print("The number is not prime")
    