# SYNTAX : string.format(value1,value2)

name = "Nandini"
age = 20
print("My name is {} and I am {} years old.".format(name, age))