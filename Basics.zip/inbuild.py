n="nandini"
b="chetna chowdary"
print(n.lower())
print(n.upper())
print(b.capitalize())   #makes the first letter of the string uppercase
print(n.find("d"))  
print(n.swapcase())
print(n.title())  #Makes the first letter of each word uppercase
print(b.title())
print(len(n))


