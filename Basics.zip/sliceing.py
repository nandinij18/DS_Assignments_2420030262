#SLICEING
text="Hello, World!"
print(text[2:5])  # returns characters from position 2 to 5 (not included)
print(text[:5])  # returns characters from the beginning to position 5 (not included)
print(text[2:])  # returns characters from position 2 to the end