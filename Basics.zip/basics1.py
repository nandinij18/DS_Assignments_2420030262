print("hi")

a,b,c=5,8,9
print(a,b,c,sep="*")

n=input("Enter your name: ")
print(n)

x,y,z="Bannana","Apple","orange"
print(x,y,z)

#name

i=int(input("Enter a num: "))
if i>=5:
    print("Greater than 5")
else:
    print("not greater than 5")
    
#TO KNOW WHICH DATATYPE IT IS
a=12
b=12.5
c="John"
print(type(a))
print(type(b))
print(type(c))

#TYPECASTING -(TO CONVERT ONE DATATYPE TO ANOTHER)
d=float(2)  # converting integer to float
R= int(3.89)  # converting float to integer
Y=str("Hello")  # converting string to string
print(d)
print(R)
print(Y)

#SLICEING
text="Hello, World!"
print(text[2:5])  # returns characters from position 2 to 5 (not included)
print(text[:5])  # retur                                        ns characters from the beginning to position 5 (not included)
print(text[2:])  # returns characters from position 2 to the end

