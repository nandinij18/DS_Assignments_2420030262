i=int(input("Enter a num: "))
if i>=5:
    print("Greater than 5")
else:
    print("not greater than 5")