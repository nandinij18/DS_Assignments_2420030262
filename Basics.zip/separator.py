a,b,c=5,8,9
print(a,b,c,sep="*")