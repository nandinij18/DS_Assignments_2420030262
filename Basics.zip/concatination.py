a="klh"
b="BOWRAMPATE"
c=a+b
d=a*b
print(c)