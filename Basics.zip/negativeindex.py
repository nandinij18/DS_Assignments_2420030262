#neagativeindexing

b="Hello, World!"
print(b[-5:-2])  # returns characters from position -5 to -2 (not included)  (reversestarting from-1)