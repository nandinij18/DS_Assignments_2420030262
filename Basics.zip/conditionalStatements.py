#IF CONDITIONAL STATEMENTS
89
a=90
b=78
if(a>b):
    print("a is greater than b")
else:
    print("b is greater than a")
    
    
    
#WRITE A PROGRAM TO CHECK WHETHER THE NUMBER IS EVEN OR ODD
num=int(input("Enter the number: "))
if(num%2==0):
    print("The number is even")
else:
    print("The number is odd")
    
    
    
#WRITE A PROGRAM TO FIND BIGGER OF 3 NUMBERS
a,b,c=map(int,input("Enter three numbers: ").split())
if(a>b and a>c):
    print(a,"is the biggest number")
elif(b>a and b>c):
    print(b ,"is the biggest number")
else:
    print(c,"is the biggest number")


#WRITE A PROGRAM TO CHECK WHETHER THE NUMBER IS POSITIVE OR NEGATIVE
num=int(input("Enter the number: "))
if(num>0):
    print("The number is positive")
elif(num<0):
    print("The number is negative")
else:
    print("The number is zero")
    