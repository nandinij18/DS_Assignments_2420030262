#TO KNOW WHICH DATATYPE IT IS
a=12
b=12.5
c="John"
print(type(a))
print(type(b))
print(type(c))