#TYPECASTING -(TO CONVERT ONE DATATYPE TO ANOTHER)
d=float(2)  # converting integer to float
R= int(3.89)  # converting float to integer
Y=str("Hello")  # converting string to string
print(d)
print(R)
print(Y)
