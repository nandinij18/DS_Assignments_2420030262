#discrete random variable

student=[10,20,30,50,60]
print("total students")
print(student)

#continious random variable

height=[150.5,160.2,172.8,165.4,158.7]
print("Student Height:")
print(height)