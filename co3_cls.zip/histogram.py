import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
p=0.3
data=np.random.binomial(1,p,1000)
sns.histplot(data, stat="density", discrete=True)
plt.title(f"Bernoulli Distribution (p={p})")
plt.xlabel("Outcome (0=failure,1=success)")
plt.ylabel("Density")
plt.xticks([0,1])
plt.show()
